# coding: utf-8

from distutils.core import setup
setup(name='PythonSmallModule',  #打包后的包文件名
      version='1.0',
      description='python module backpack', #说明
      author='sydjcwx',
      author_email='lyzy19520@163.com',
      url='https://github.com/sydjcwx/Python-Small-Module.git',
      py_modules=['PythonSmallModule.python-small-module'],   #你要打包的文件
)